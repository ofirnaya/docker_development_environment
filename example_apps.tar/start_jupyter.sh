#!/bin/sh


cd /home/developer/

sudo PYSPARK_PYTHON=python3 PYSPARK_DRIVER_PYTHON=python3 -u developer /usr/local/bin/jupyter notebook
