#!/bin/sh

export PYSPARK_PYTHON=python3
export PYSPARK_DRIVER_PYTHON=python3

cd /home/developer/

sudo -u developer /usr/local/bin/jupyter notebook
