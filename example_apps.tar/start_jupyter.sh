#!/bin/sh

export PYSPARK_PYTHON=python3
export PYSPARK_DRIVER_PYTHON=python3

jupyter notebook
